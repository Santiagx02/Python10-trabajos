#Generador de contraseñas
import random

minus = "abcdefghijklmñopqrstuvwxyz"
mayus = "ABCDEFGHIJKLMNÑOPQRSTUVWYZ"
numeros = "0123456789"
simbolos = "#$%&"

base = minus+mayus+numeros+simbolos
longitud=10

muestra=random.sample(base, longitud)
password= "".join(muestra)
print(password)
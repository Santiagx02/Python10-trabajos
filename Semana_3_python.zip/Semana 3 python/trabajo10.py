#Gestion Lista de productos
compra =[]
print('Bienvenido al programa de lista de compras')
while True:
    print ("1 Añadir productos")
    print ("2 Eliminar productos")
    print ("3 Ver productos")
    print ("4 Salir del programa")
    print ()
    opcion = input("-->")
    print ()

    if opcion =="1":
        producto = input ("Introduce el producto: ")
        if producto in compra:
            print ("Ese producto ya está")
        else:
            compra.append (producto)
    elif opcion == "3":
        print("Lista compra")
        for e in compra:
            print(" -", e)
    elif opcion == "4":
        break






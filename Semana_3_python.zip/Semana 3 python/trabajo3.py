#Contador de palabras
oracion= "Juan salio el viernes a tomar con sus amigos polas despues de salir de la uniersidad"
palabras: 0
indice = 0

while indice < len(oracion):
    if oracion [indice] == " " or indice == len(oracion) - 1:
        palabras += 1
indice += 1
print (f"la cantidad de palabras en la oracion es:  {palabras} " )
#dados
import random

def lanzar_dados():
    dado1 = random.randint(1, 6) 
    dado2 = random.randint(1, 6)  
    return dado1, dado2

dado1, dado2 = lanzar_dados()
print("Resultado del primer dado:", dado1)
print("Resultado del segundo dado:", dado2)

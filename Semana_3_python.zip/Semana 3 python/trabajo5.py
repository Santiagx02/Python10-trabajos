#Palindromos
palindromos= ['oso', 'anilina','Aerea','carro', 'avion', 'rapar']
def es_palindromo(p):
    estandar = str(p).lower().replace(' ', '')
    return estandar == estandar[::-1]
if __name__ =='__main__':
    for p in palindromos:
        resultado = es_palindromo(p)
        print(resultado)
#Juego de adivinazas de numero

import random
numero_aleatoria= random.randint(1,150)
intentos= 0
while True:
    numero_usuario=int(input("Inserte un número entre 1/150:"))
    if numero_usuario > numero_aleatoria:
        intentos += 1
        print ("El número es menor, intentalo de nuevo")
    elif numero_usuario < numero_aleatoria:
        intentos += 1
        print ("El número es mayor, intentalo de nuevo")
    else:
        intentos += 1
        print ("¡FELICITACIONES, HAZ DESCUBIERTO EL NÚMERO!", numero_aleatoria)
        break
#Calculadora de interes compuesto
def calcular_interes_compuesto(principal, tasa, periodos):
    monto_futuro = principal * (1 + tasa)**periodos
    return monto_futuro


principal = float(input("Ingrese el monto principal: "))
tasa_interes = float(input("Ingrese la tasa de interés anual (%): "))
periodos = int(input("Ingrese el número de períodos (años): "))

monto_futuro = calcular_interes_compuesto(principal, tasa_interes, periodos)
print("El monto futuro después de", periodos, "años será:", monto_futuro)
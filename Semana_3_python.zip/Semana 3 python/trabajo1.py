#Convertir metros a pies
metro = float (input("metro:"))
convertir = metro * 3.28084
print(f'{convertir} ft')

#convertir pies a pulgadas
pies = float(input("pies:"))
convertir= pies * 12
print (f'{convertir} pulgadas')